﻿using MediatR;
using Questao5.Application.Commands;
using Questao5.Application.Queries;
using Dapper;
using System.Data;
using System.Threading;
using System.Threading.Tasks;
using Questao5.Application.Queries.Responses;

namespace Questao5.Application.Handlers
{
    public class ConsultarSaldoHandler : IRequestHandler<ConsultarSaldoQuery, QueryResult>
    {
        private readonly IDbConnection _dbConnection;

        public ConsultarSaldoHandler(IDbConnection dbConnection)
        {
            _dbConnection = dbConnection;
        }

        public async Task<QueryResult> Handle(ConsultarSaldoQuery request, CancellationToken cancellationToken)
        {
            // Lógica de consulta de saldo (similar ao controlador)
            // ...
            return new QueryResult { Sucesso = true, NumeroConta = 123, SaldoAtual = 1000.00M };
        }
    }
}
